-- MariaDB dump 10.17  Distrib 10.4.6-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: uber_eats
-- ------------------------------------------------------
-- Server version	10.4.6-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers_list`
--

DROP TABLE IF EXISTS `customers_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers_list` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` varchar(50) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `customer_gender` enum('male','female','other') NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers_list`
--

LOCK TABLES `customers_list` WRITE;
/*!40000 ALTER TABLE `customers_list` DISABLE KEYS */;
INSERT INTO `customers_list` VALUES (1,'Hernando Richardeau','70099 Randy Trail','hrichardeau0@fotki.com','male','314-760-9969'),(2,'Humphrey Steel','74221 Corry Road','hsteel1@earthlink.net','male','730-141-2318'),(3,'Tess Sturdy','8266 Dawn Point','tsturdy2@delicious.com','female','989-939-0218'),(4,'Suzie MacAvaddy','62 Arapahoe Point','smacavaddy3@bloglovin.com','female','552-574-4908'),(5,'Redd Cullinan','67 Summerview Avenue','rcullinan4@behance.net','male','685-598-8028'),(6,'Morganica Henrichsen','01 Bluejay Place','mhenrichsen5@elegantthemes.com','female','899-712-8820'),(7,'Skyler Grenter','13353 Gina Junction','sgrenter6@github.io','male','798-836-2184'),(8,'Willi Sheehy','8811 Pepper Wood Parkway','wsheehy7@stumbleupon.com','female','218-929-7640'),(9,'Dominique Chettle','093 Parkside Hill','dchettle8@baidu.com','male','289-720-4158'),(10,'Trescha Jiggen','2504 Lakewood Plaza','tjiggen9@elpais.com','female','264-453-7560'),(11,'rizul','6 tolton drive','rizul@gmail.com','male','647-667-8029');
/*!40000 ALTER TABLE `customers_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees_list`
--

DROP TABLE IF EXISTS `employees_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees_list` (
  `employee_id` int(11) NOT NULL,
  `employee_name` varchar(50) NOT NULL,
  `employee_address` varchar(50) NOT NULL,
  `employee_email` varchar(40) NOT NULL,
  `employee_gender` enum('male','female','other') NOT NULL,
  `employee_phone` varchar(15) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees_list`
--

LOCK TABLES `employees_list` WRITE;
/*!40000 ALTER TABLE `employees_list` DISABLE KEYS */;
INSERT INTO `employees_list` VALUES (1,'Page Breckon','468 Caliangt Way','pbreckon0@blogs.com','female','654-944-1835'),(2,'Bordie Joan','5 Dryden Hill','bjoan1@arizona.edu','male','664-844-8057'),(3,'Rudiger McLaren','19578 Dwight Junction','rmclaren2@businesswire.com','male','619-473-5055'),(4,'Rossie Tabert','83813 Lukken Court','rtabert3@va.gov','male','239-543-9250'),(5,'Dominique Mogenot','517 Farmco Way','dmogenot4@cafepress.com','male','917-637-7026'),(6,'Mayer Pullman','662 Beilfuss Point','mpullman5@prweb.com','male','480-826-5140'),(7,'Micheline Monsey','05 Farragut Trail','mmonsey6@google.es','female','320-792-7850'),(8,'Monty Stroband','47923 Melody Circle','mstroband7@vk.com','male','928-934-1837'),(9,'Ade Navan','87 Troy Street','anavan8@squidoo.com','male','495-494-9610'),(10,'Miran Maydway','4 Mayer Lane','mmaydway9@admin.ch','female','860-146-1315');
/*!40000 ALTER TABLE `employees_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `feedback_customer` int(3) DEFAULT NULL,
  `feedback_rating` enum('1','2','3','4','5') NOT NULL,
  `feedback_remarks` varchar(200) DEFAULT NULL,
  KEY `feedback_customer` (`feedback_customer`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`feedback_customer`) REFERENCES `customers_list` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (2,'3','good service with excellent food quality'),(3,'5','excellent service. I am very happy to the service of uber eats . '),(6,'4','First time ordering from uber eats fantastic service, fast'),(7,'1','Lousy service. Uou order and wait Donot bother tipping. '),(9,'2','The worst app i ever used...not at all secured.');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_list`
--

DROP TABLE IF EXISTS `menu_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_list` (
  `menu_id` int(3) NOT NULL,
  `menu_restaurant` int(3) DEFAULT NULL,
  `menu_product` int(3) DEFAULT NULL,
  PRIMARY KEY (`menu_id`),
  KEY `menu_restaurant` (`menu_restaurant`),
  KEY `menu_product` (`menu_product`),
  CONSTRAINT `menu_list_ibfk_1` FOREIGN KEY (`menu_restaurant`) REFERENCES `restaurants_list` (`restaurant_id`),
  CONSTRAINT `menu_list_ibfk_2` FOREIGN KEY (`menu_product`) REFERENCES `products_list` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_list`
--

LOCK TABLES `menu_list` WRITE;
/*!40000 ALTER TABLE `menu_list` DISABLE KEYS */;
INSERT INTO `menu_list` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,6),(6,2,8),(7,2,14),(8,2,9),(9,2,11),(10,2,10),(11,3,14),(12,3,12),(13,3,11),(14,4,13),(15,4,14),(16,4,12),(17,5,5),(18,5,7),(19,5,4),(20,5,6);
/*!40000 ALTER TABLE `menu_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_details` (
  `orderdetails_id` int(3) DEFAULT NULL,
  `order_restaurant` int(3) DEFAULT NULL,
  `order_product_id` int(3) DEFAULT NULL,
  `order_quantity` int(2) NOT NULL,
  KEY `order_restaurant` (`order_restaurant`),
  KEY `orderdetails_id` (`orderdetails_id`),
  KEY `order_product_id` (`order_product_id`),
  CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_restaurant`) REFERENCES `restaurants_list` (`restaurant_id`),
  CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`orderdetails_id`) REFERENCES `order_history` (`order_id`),
  CONSTRAINT `order_details_ibfk_3` FOREIGN KEY (`order_product_id`) REFERENCES `products_list` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_details`
--

LOCK TABLES `order_details` WRITE;
/*!40000 ALTER TABLE `order_details` DISABLE KEYS */;
INSERT INTO `order_details` VALUES (1,1,1,3),(1,1,2,2),(1,1,6,5),(2,2,8,4),(2,2,14,2),(2,2,9,6),(2,2,10,5),(3,5,7,8),(3,5,4,2),(3,5,6,3),(4,4,8,4),(4,4,13,3),(5,2,12,3),(5,1,4,3),(5,1,2,3),(5,1,1,4),(6,3,12,8);
/*!40000 ALTER TABLE `order_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_history`
--

DROP TABLE IF EXISTS `order_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_history` (
  `order_id` int(3) NOT NULL,
  `order_customer` int(3) DEFAULT NULL,
  `order_employee` int(3) DEFAULT NULL,
  `order_date` date NOT NULL,
  `order_status` enum('on the way','in processing','delivered','cancelled') DEFAULT 'in processing',
  `order_payment_type` enum('Cash','Card') NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `order_customer` (`order_customer`),
  KEY `order_employee` (`order_employee`),
  CONSTRAINT `order_history_ibfk_1` FOREIGN KEY (`order_customer`) REFERENCES `customers_list` (`customer_id`),
  CONSTRAINT `order_history_ibfk_2` FOREIGN KEY (`order_employee`) REFERENCES `employees_list` (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_history`
--

LOCK TABLES `order_history` WRITE;
/*!40000 ALTER TABLE `order_history` DISABLE KEYS */;
INSERT INTO `order_history` VALUES (1,3,5,'2019-09-12','delivered','Card'),(2,2,4,'2019-09-12','in processing','Card'),(3,6,7,'2019-09-12','in processing','Cash'),(4,1,2,'2019-09-12','in processing','Cash'),(5,3,10,'2019-09-12','in processing','Card'),(6,9,2,'2019-09-12','in processing','Card'),(7,NULL,8,'2019-09-14','delivered','Card');
/*!40000 ALTER TABLE `order_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentcard_details`
--

DROP TABLE IF EXISTS `paymentcard_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paymentcard_details` (
  `paymentcard_customer` int(3) DEFAULT NULL,
  `paymentcard_type` enum('credit card','debit card','master card') NOT NULL,
  `paymentcard_number` int(12) NOT NULL,
  `paymentcard_cvv` int(3) NOT NULL,
  `paymentcard_expirydate` date NOT NULL,
  KEY `paymentcard_customer` (`paymentcard_customer`),
  CONSTRAINT `paymentcard_details_ibfk_1` FOREIGN KEY (`paymentcard_customer`) REFERENCES `customers_list` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentcard_details`
--

LOCK TABLES `paymentcard_details` WRITE;
/*!40000 ALTER TABLE `paymentcard_details` DISABLE KEYS */;
INSERT INTO `paymentcard_details` VALUES (1,'credit card',2147483647,426,'2021-09-05'),(1,'debit card',2147483647,352,'2023-10-11'),(2,'master card',2147483647,251,'2020-02-21'),(4,'credit card',2147483647,715,'2022-04-23'),(8,'master card',2147483647,584,'2021-11-30'),(5,'master card',2147483647,352,'2023-10-11'),(4,'master card',2147483647,654,'2024-06-29'),(3,'debit card',2147483647,821,'2022-11-15'),(7,'credit card',2147483647,587,'2019-05-29');
/*!40000 ALTER TABLE `paymentcard_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_list`
--

DROP TABLE IF EXISTS `products_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_list` (
  `product_id` int(3) NOT NULL,
  `product_name` varchar(30) NOT NULL,
  `product_description` enum('vegetarian','non-vegetarian') NOT NULL,
  `product_price` float DEFAULT NULL CHECK (`product_price` > 0),
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_list`
--

LOCK TABLES `products_list` WRITE;
/*!40000 ALTER TABLE `products_list` DISABLE KEYS */;
INSERT INTO `products_list` VALUES (1,'butter chicken','non-vegetarian',10.5),(2,'karahi paneer','vegetarian',12),(3,'Dal Makhani','vegetarian',9),(4,'Plain Naan','vegetarian',2.5),(5,'Chole Bhature','vegetarian',8.5),(6,'Amritsari Kulcha','vegetarian',9.75),(7,'Lemon Chicken','non-vegetarian',11.5),(8,'Chicken Teryaki','non-vegetarian',15),(9,'Italian Pasta','non-vegetarian',12.25),(10,'Chicken Salad','non-vegetarian',8.5),(11,'Potato Crisper','vegetarian',2.25),(12,'French Fries','vegetarian',2.3),(13,'Junior Chicken','non-vegetarian',1.75),(14,'Veggie Wrap','vegetarian',8.75);
/*!40000 ALTER TABLE `products_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurants_list`
--

DROP TABLE IF EXISTS `restaurants_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurants_list` (
  `restaurant_id` int(3) NOT NULL,
  `restaurant_name` varchar(30) NOT NULL,
  `restaurant_address` varchar(50) NOT NULL,
  `restaurant_phone` varchar(15) NOT NULL,
  `restaurant_email` varchar(30) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurants_list`
--

LOCK TABLES `restaurants_list` WRITE;
/*!40000 ALTER TABLE `restaurants_list` DISABLE KEYS */;
INSERT INTO `restaurants_list` VALUES (1,'Prem Sweets','48225 Thackeray Center','626-827-3271','osmows120@phpbb.com'),(2,'Subway','15 Roxbury Terrace','529-567-0910','subway125@sogou.com'),(3,'Mcdonalds','2161 Westport Court','244-397-6703','mocdonalds234@homestead.com'),(4,'Tim Hortons','9 Melrose Parkway','332-679-2498','timhortons12B@sourceforge.net'),(5,'India Taste','2375 Troy Way','900-321-4361','itaste61@digg.com');
/*!40000 ALTER TABLE `restaurants_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v1`
--

DROP TABLE IF EXISTS `v1`;
/*!50001 DROP VIEW IF EXISTS `v1`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v1` (
  `customer_id` tinyint NOT NULL,
  `customer_name` tinyint NOT NULL,
  `customer_address` tinyint NOT NULL,
  `customer_email` tinyint NOT NULL,
  `customer_gender` tinyint NOT NULL,
  `customer_phone` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v2`
--

DROP TABLE IF EXISTS `v2`;
/*!50001 DROP VIEW IF EXISTS `v2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v2` (
  `product_name` tinyint NOT NULL,
  `concat('$',format(product_price,2))` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v1`
--

/*!50001 DROP TABLE IF EXISTS `v1`*/;
/*!50001 DROP VIEW IF EXISTS `v1`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v1` AS select `customers_list`.`customer_id` AS `customer_id`,`customers_list`.`customer_name` AS `customer_name`,`customers_list`.`customer_address` AS `customer_address`,`customers_list`.`customer_email` AS `customer_email`,`customers_list`.`customer_gender` AS `customer_gender`,`customers_list`.`customer_phone` AS `customer_phone` from `customers_list` where `customers_list`.`customer_id` > 5 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v2`
--

/*!50001 DROP TABLE IF EXISTS `v2`*/;
/*!50001 DROP VIEW IF EXISTS `v2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v2` AS select `products_list`.`product_name` AS `product_name`,concat('$',format(`products_list`.`product_price`,2)) AS `concat('$',format(product_price,2))` from `products_list` order by `products_list`.`product_price` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-09-16 13:27:22
